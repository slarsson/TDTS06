# PROXY MY PROXY

## TESTS

http://zebroid.ida.liu.se/fakenews/test1.txt

http://zebroid.ida.liu.se/fakenews/test2.html

http://zebroid.ida.liu.se/fakenews/test3.html

http://zebroid.ida.liu.se/fakenews/test4.html

http://zebroid.ida.liu.se/fakenews/smiley.jpg

## INSTALL
```
pip install -r requirements.txt
```

## RUN
```
python proxy.py
```